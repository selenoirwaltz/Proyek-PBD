@extends('layouts.app')
@section('judul', 'Role')

@section('content')
<div class="card">
  <h2>{{ $edit ? 'Ubah role' : 'Tambah role' }}</h2>
  <form method="post" action="{{ $edit ? url('role/'.$edit->idrole) : url('role') }}">
    @csrf
    @if ($edit) @method('PUT') @endif
    <div class="grid">
      <div><label>Nama role</label>
        <input name="nama_role" maxlength="100" required value="{{ old('nama_role', $edit?->nama_role) }}"></div>
    </div>
    <div class="aksi">
      <button class="btn">{{ $edit ? 'Simpan perubahan' : 'Tambah' }}</button>
      @if ($edit)<a class="btn batal" href="{{ url('role') }}">Batal</a>@endif
    </div>
  </form>
</div>

<div class="tabel-wrap">
<table>
  <tr><th>No.</th><th>Role</th><th>Total User</th><th>Aksi</th></tr>
  @forelse ($rows as $r)
  <tr>
    <td>{{ $r->{'No.'} }}</td>
    <td>{{ $r->{'Role'} }}</td>
    <td>{{ $r->{'Total User'} }}</td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit={{ $r->{'No.'} }}">Ubah</a>
      <form method="post" action="{{ url('role/'.$r->{'No.'}) }}" onsubmit="return confirm('Hapus role ini?')">
        @csrf
        @method('DELETE')
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  @empty
  <tr><td colspan="4" class="kosong">Belum ada data.</td></tr>
  @endforelse
</table>
</div>
@endsection
