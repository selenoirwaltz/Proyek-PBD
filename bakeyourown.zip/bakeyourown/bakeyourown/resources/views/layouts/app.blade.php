<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>@yield('judul') - BakeYourOwn Inventory</title>
  <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>

  {{-- 1. TOMBOL HAMBURGER (ini yang tadi kelupaan, taruh paling atas di body) --}}
  <button id="sidebar-toggle" class="hamburger-btn">&#9776;</button>

  {{-- 2. SIDEBAR --}}
  @php
    $menu = ['/' => 'Beranda', 'barang' => 'Barang', 'satuan' => 'Satuan', 'vendor' => 'Vendor',
             'margin-penjualan' => 'Margin Penjualan', 'user' => 'User', 'role' => 'Role'];
  @endphp
  <aside id="sidebar" class="sidebar">
    <div class="sidebar-header"><h3>BakeYourOwn Inventory</h3></div>
    <ul class="sidebar-menu">
      @foreach ($menu as $url => $nama)
        <li><a href="{{ url($url) }}" class="{{ request()->is($url === '/' ? '/' : $url.'*') ? 'active' : '' }}">{{ $nama }}</a></li>
      @endforeach
    </ul>
  </aside>

  {{-- 3. KONTEN UTAMA --}}
  <div id="main-content" class="main-content">
    <div class="container">
      {{-- salin markup flash dari header.php lama ke sini --}}
      @yield('content')
    </div>
  </div>

  {{-- 4. SCRIPT TOGGLE (taruh paling bawah, sebelum </body>) --}}
  <script>
      const toggleBtn = document.getElementById('sidebar-toggle');
      const sidebar = document.getElementById('sidebar');
      const mainContent = document.getElementById('main-content');

      toggleBtn.addEventListener('click', function() {
          sidebar.classList.toggle('closed');
          mainContent.classList.toggle('expanded');
      });
  </script>
</body>
</html>
