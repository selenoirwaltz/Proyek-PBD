@extends('layouts.app')
@section('judul', 'User')

@section('content')
<div class="card">
  <h2>{{ $edit ? 'Ubah user' : 'Tambah user' }}</h2>
  <form method="post" action="{{ $edit ? url('user/'.$edit->iduser) : url('user') }}">
    @csrf
    @if ($edit) @method('PUT') @endif
    <div class="grid">
      <div><label>Username</label>
        <input name="username" maxlength="45" required value="{{ old('username', $edit?->username) }}"></div>
      <div><label>Password {{ $edit ? '(kosongkan jika tidak diganti)' : '' }}</label>
        <input type="password" name="password" maxlength="50" {{ $edit ? '' : 'required' }}></div>
      <div><label>Role</label>
        <select name="idrole" required>
          <option value="">-- pilih role --</option>
          @foreach ($daftarRole as $rl)
            <option value="{{ $rl->idrole }}" {{ old('idrole', $edit?->idrole) == $rl->idrole ? 'selected' : '' }}>{{ $rl->nama_role }}</option>
          @endforeach
        </select></div>
    </div>
    <div class="aksi">
      <button class="btn">{{ $edit ? 'Simpan perubahan' : 'Tambah' }}</button>
      @if ($edit)<a class="btn batal" href="{{ url('user') }}">Batal</a>@endif
    </div>
  </form>
</div>

<div class="tabel-wrap">
<table>
  <tr><th>No.</th><th>Nama User</th><th>Role</th><th>Aksi</th></tr>
  @forelse ($rows as $r)
  <tr>
    <td>{{ $r->{'No.'} }}</td>
    <td>{{ $r->{'Nama User'} }}</td>
    <td>{{ $r->{'Role'} }}</td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit={{ $r->{'No.'} }}">Ubah</a>
      <form method="post" action="{{ url('user/'.$r->{'No.'}) }}" onsubmit="return confirm('Hapus user ini?')">
        @csrf
        @method('DELETE')
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  @empty
  <tr><td colspan="4" class="kosong">Belum ada data.</td></tr>
  @endforelse
</table>
</div>
@endsection
