@extends('layouts.app')
@section('judul', 'Satuan')

@section('content')
<div class="card">
  <h2>{{ $edit ? 'Ubah satuan' : 'Tambah satuan' }}</h2>
  <form method="post" action="{{ $edit ? url('satuan/'.$edit->idsatuan) : url('satuan') }}">
    @csrf
    @if ($edit) @method('PUT') @endif
    <div class="grid">
      <div><label>Nama satuan</label>
        <input name="nama_satuan" maxlength="45" required value="{{ old('nama_satuan', $edit?->nama_satuan) }}"></div>
      <div><label>Status</label>
        <input type="number" name="status" min="0" max="9" required value="{{ old('status', $edit?->status ?? 1) }}"></div>
    </div>
    <div class="aksi">
      <button class="btn">{{ $edit ? 'Simpan perubahan' : 'Tambah' }}</button>
      @if ($edit)<a class="btn batal" href="{{ url('satuan') }}">Batal</a>@endif
    </div>
  </form>
</div>

<div class="tabel-wrap">
<table>
  <tr><th>No.</th><th>Satuan</th><th>Jumlah Barang</th><th>Status Barang</th><th>Aksi</th></tr>
  @forelse ($rows as $r)
  <tr>
    <td>{{ $r->{'No.'} }}</td>
    <td>{{ $r->{'Satuan'} }}</td>
    <td>{{ $r->{'Jumlah Barang'} }}</td>
    <td>
      @if ($r->{'Status Barang'} == 1)
        <span class="badge aktif">Aktif</span>
      @else
        <span class="badge nonaktif">Tidak Aktif</span>
      @endif
    </td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit={{ $r->{'No.'} }}">Ubah</a>
      <form method="post" action="{{ url('satuan/'.$r->{'No.'}) }}" onsubmit="return confirm('Hapus satuan ini?')">
        @csrf
        @method('DELETE')
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  @empty
  <tr><td colspan="5" class="kosong">Belum ada data.</td></tr>
  @endforelse
</table>
</div>
@endsection
