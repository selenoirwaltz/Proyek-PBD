@extends('layouts.app')
@section('judul', 'Barang')

@section('content')
<div class="card">
  <h2>{{ $edit ? 'Ubah barang' : 'Tambah barang' }}</h2>
  <form method="post" action="{{ $edit ? url('barang/'.$edit->idbarang) : url('barang') }}">
    @csrf
    @if ($edit) @method('PUT') @endif
    <div class="grid">
      <div><label>Nama barang</label>
        <input name="nama" maxlength="45" required value="{{ old('nama', $edit?->nama) }}"></div>
      <div><label>Jenis (1 huruf, mis. a / b / c)</label>
        <input name="jenis" maxlength="1" required value="{{ old('jenis', $edit?->jenis) }}"></div>
      <div><label>Satuan</label>
        <select name="idsatuan" required>
          <option value="">-- pilih satuan --</option>
          @foreach ($daftarSatuan as $s)
            <option value="{{ $s->idsatuan }}" {{ old('idsatuan', $edit?->idsatuan) == $s->idsatuan ? 'selected' : '' }}>{{ $s->nama_satuan }}</option>
          @endforeach
        </select></div>
      <div><label>Harga (Rp)</label>
        <input type="number" name="harga" min="0" required value="{{ old('harga', $edit?->harga) }}"></div>
      <div><label>Status</label>
        <input type="number" name="status" min="0" max="9" required value="{{ old('status', $edit?->status ?? 1) }}"></div>
    </div>
    <div class="aksi">
      <button class="btn">{{ $edit ? 'Simpan perubahan' : 'Tambah' }}</button>
      @if ($edit)<a class="btn batal" href="{{ url('barang') }}">Batal</a>@endif
    </div>
  </form>
</div>

<div class="tabel-wrap">
<h3>Barang Aktif</h3>
<table>
  <tr><th>No.</th><th>Jenis Barang</th><th>Nama Barang</th><th>Harga Barang</th><th>Satuan</th><th>Status Barang</th><th>Aksi</th></tr>
  @forelse ($rows as $r)
  <tr>
    <td>{{ $r->{'No.'} }}</td>
    <td>{{ $r->{'Jenis Barang'} }}</td>
    <td>{{ $r->{'Nama Barang'} }}</td>
    <td>Rp {{ number_format($r->{'Harga Barang'}, 0, ',', '.') }}</td>
    <td>{{ $r->{'Satuan'} }}</td>
    <td>
      @if ($r->{'Status Barang'} == 1)
        <span class="badge aktif">Aktif</span>
      @else
        <span class="badge nonaktif">Tidak Aktif</span>
      @endif
    </td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit={{ $r->{'No.'} }}">Ubah</a>
      <form method="post" action="{{ url('barang/'.$r->{'No.'}) }}" onsubmit="return confirm('Hapus barang ini?')">
        @csrf
        @method('DELETE')
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  @empty
  <tr><td colspan="7" class="kosong">Belum ada data.</td></tr>
  @endforelse
</table>
</div>

<div class="tabel-wrap" style="margin-top: 30px;">
<h3>Barang Nonaktif</h3>
<table>
  <tr><th>No.</th><th>Jenis Barang</th><th>Nama Barang</th><th>Harga Barang</th><th>Satuan</th><th>Status Barang</th><th>Aksi</th></tr>
  @forelse ($rows2 as $r)
  <tr>
    <td>{{ $r->{'No.'} }}</td>
    <td>{{ $r->{'Jenis Barang'} }}</td>
    <td>{{ $r->{'Nama Barang'} }}</td>
    <td>Rp {{ number_format($r->{'Harga Barang'}, 0, ',', '.') }}</td>
    <td>{{ $r->{'Satuan'} }}</td>
    <td><span class="badge nonaktif">Tidak Aktif</span></td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit={{ $r->{'No.'} }}">Ubah</a>
      <form method="post" action="{{ url('barang/'.$r->{'No.'}) }}" onsubmit="return confirm('Hapus barang ini?')">
        @csrf
        @method('DELETE')
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  @empty
  <tr><td colspan="7" class="kosong">Tidak ada data barang yang tidak aktif.</td></tr>
  @endforelse
</table>
</div>

<div class="tabel-wrap" style="margin-top: 30px;">
<h3>Harga di Bawah Rp20.000</h3>
<table>
  <tr><th>No.</th><th>Jenis</th><th>Nama Barang</th><th>Harga</th></tr>
  @forelse ($hargaMurah as $sm)
  <tr>
    <td>{{ $sm->idbarang }}</td>
    <td>{{ $sm->jenis }}</td>
    <td>{{ $sm->nama }}</td>
    <td>Rp {{ number_format($sm->harga, 0, ',', '.') }}</td>
  </tr>
  @empty
  <tr><td colspan="4" class="kosong">Tidak ada harga di bawah Rp20.000</td></tr>
  @endforelse
</table>
</div>
@endsection
