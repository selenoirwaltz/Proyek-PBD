@extends('layouts.app')
@section('judul', 'Margin Penjualan')

@section('content')
<div class="card">
  <h2>{{ $edit ? 'Ubah margin' : 'Tambah margin' }}</h2>
  <form method="post" action="{{ $edit ? url('margin-penjualan/'.$edit->idmargin_penjualan) : url('margin-penjualan') }}">
    @csrf
    @if ($edit) @method('PUT') @endif
    <div class="grid">
      <div><label>Persen (%)</label>
        <input type="number" name="persen" step="0.01" min="0" required value="{{ old('persen', $edit?->persen) }}"></div>
      <div><label>Status</label>
        <input type="number" name="status" min="0" max="9" required value="{{ old('status', $edit?->status ?? 1) }}"></div>
      <div><label>Dibuat oleh (user)</label>
        <select name="iduser" required>
          <option value="">-- pilih user --</option>
          @foreach ($daftarUser as $u)
            <option value="{{ $u->iduser }}" {{ old('iduser', $edit?->iduser) == $u->iduser ? 'selected' : '' }}>{{ $u->username }}</option>
          @endforeach
        </select></div>
    </div>
    <div class="aksi">
      <button class="btn">{{ $edit ? 'Simpan perubahan' : 'Tambah' }}</button>
      @if ($edit)<a class="btn batal" href="{{ url('margin-penjualan') }}">Batal</a>@endif
    </div>
  </form>
</div>

<div class="tabel-wrap">
<table>
  <tr><th>No.</th><th>Persentase</th><th>Status Margin</th><th>Nama User</th><th>Tanggal Dibuat</th><th>Tanggal Diubah</th><th>Aksi</th></tr>
  @forelse ($rows as $r)
  <tr>
    <td>{{ $r->{'No.'} }}</td>
    <td>{{ $r->{'Persentase'} }}%</td>
    <td>{{ $r->{'Status Margin'} }}</td>
    <td>{{ $r->{'Nama User'} }}</td>
    <td>{{ $r->{'Tanggal Dibuat'} }}</td>
    <td>{{ $r->{'Tanggal Diubah'} ?? '-' }}</td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit={{ $r->{'No.'} }}">Ubah</a>
      <form method="post" action="{{ url('margin-penjualan/'.$r->{'No.'}) }}" onsubmit="return confirm('Hapus margin ini?')">
        @csrf
        @method('DELETE')
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  @empty
  <tr><td colspan="7" class="kosong">Belum ada data.</td></tr>
  @endforelse
</table>
</div>
@endsection
