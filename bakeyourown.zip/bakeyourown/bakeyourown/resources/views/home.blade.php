@extends('layouts.app')
@section('judul', 'Beranda')

@section('content')
<p>Kelola data master. Pilih tabel di bawah untuk tambah, ubah, atau hapus data.</p>
<div class="menu-grid">
  <a href="{{ url('satuan') }}">Satuan <small>{{ $jumlah['satuan'] }} data</small></a>
  <a href="{{ url('vendor') }}">Vendor <small>{{ $jumlah['vendor'] }} data</small></a>
  <a href="{{ url('role') }}">Role <small>{{ $jumlah['role'] }} data</small></a>
  <a href="{{ url('barang') }}">Barang <small>{{ $jumlah['barang'] }} data</small></a>
  <a href="{{ url('user') }}">User <small>{{ $jumlah['user'] }} data</small></a>
  <a href="{{ url('margin-penjualan') }}">Margin Penjualan <small>{{ $jumlah['margin_penjualan'] }} data</small></a>
</div>
@endsection
