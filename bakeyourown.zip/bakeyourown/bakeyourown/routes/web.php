<?php

use App\Http\Controllers\BarangController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\MarginPenjualanController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\SatuanController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\VendorController;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, 'index']);

Route::resource('satuan', SatuanController::class)->only(['index', 'store', 'update', 'destroy']);
Route::resource('vendor', VendorController::class)->only(['index', 'store', 'update', 'destroy']);
Route::resource('role', RoleController::class)->only(['index', 'store', 'update', 'destroy']);
Route::resource('barang', BarangController::class)->only(['index', 'store', 'update', 'destroy']);
Route::resource('user', UserController::class)->only(['index', 'store', 'update', 'destroy']);
Route::resource('margin-penjualan', MarginPenjualanController::class)->only(['index', 'store', 'update', 'destroy']);
