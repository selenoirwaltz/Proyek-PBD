<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $table = 'user';
    protected $primaryKey = 'iduser';
    public $incrementing = false;
    public $timestamps = false;

    protected $fillable = ['username', 'password', 'idrole'];
    protected $hidden = ['password'];
}
