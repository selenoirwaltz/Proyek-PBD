<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MarginPenjualan extends Model
{
    protected $table = 'margin_penjualan';
    protected $primaryKey = 'idmargin_penjualan';
    public $incrementing = false;
    public $timestamps = true;      // tabel punya created_at & updated_at

    protected $fillable = ['persen', 'status', 'iduser'];
}
