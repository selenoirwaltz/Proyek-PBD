<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vendor extends Model
{
    protected $table = 'vendor';
    protected $primaryKey = 'idvendor';
    public $incrementing = false;
    public $timestamps = false;

    protected $fillable = ['nama_vendor', 'badan_hukum', 'status'];
}
