<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Barang extends Model
{
    protected $table = 'barang';
    protected $primaryKey = 'idbarang';
    public $incrementing = false;
    public $timestamps = false;

    protected $fillable = ['jenis', 'nama', 'idsatuan', 'status', 'harga'];
}
