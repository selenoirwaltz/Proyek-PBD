<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Satuan extends Model
{
    protected $table = 'satuan';
    protected $primaryKey = 'idsatuan';
    public $incrementing = false;   // id diisi manual (MAX+1) di controller
    public $timestamps = false;

    protected $fillable = ['nama_satuan', 'status'];
}
