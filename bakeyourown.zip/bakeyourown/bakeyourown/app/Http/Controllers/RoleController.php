<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Role;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        return view('role.index', [
            'edit' => $request->query('edit') ? Role::find($request->query('edit')) : null,
            'rows' => DB::select('SELECT * FROM v_rekap_role ORDER BY `No.`'),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $this->validasi($request);

        try {
            $role = new Role($data);
            $role->idrole = (Role::max('idrole') ?? 0) + 1;
            $role->save();
            return redirect('role')->with('ok', 'Role berhasil ditambahkan.');
        } catch (QueryException $e) {
            return redirect('role')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $this->validasi($request);

        try {
            Role::findOrFail($id)->update($data);
            return redirect('role')->with('ok', 'Role berhasil diubah.');
        } catch (QueryException $e) {
            return redirect('role')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            Role::findOrFail($id)->delete();
            return redirect('role')->with('ok', 'Role berhasil dihapus.');
        } catch (QueryException $e) {
            return redirect('role')->with('err', $this->pesanGalat($e));
        }
    }

    private function validasi(Request $request): array
    {
        return $request->validate([
            'nama_role' => 'required|max:100',
        ]);
    }
}
