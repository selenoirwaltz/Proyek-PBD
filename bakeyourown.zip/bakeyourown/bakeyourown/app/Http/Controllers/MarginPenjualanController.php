<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MarginPenjualan;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class MarginPenjualanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        return view('margin.index', [
            'edit'       => $request->query('edit') ? MarginPenjualan::find($request->query('edit')) : null,
            'rows'       => DB::select('SELECT * FROM v_margin_penjualan ORDER BY `No.`'),
            'daftarUser' => User::orderBy('username')->get(['iduser', 'username']),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $this->validasi($request);

        try {
            $margin = new MarginPenjualan($data);
            $margin->idmargin_penjualan = (MarginPenjualan::max('idmargin_penjualan') ?? 0) + 1;
            // saat dibuat: created_at diisi, updated_at dibiarkan kosong (sama seperti project lama)
            $margin->timestamps = false;
            $margin->created_at = now();
            $margin->save();
            return redirect('margin-penjualan')->with('ok', 'Margin penjualan berhasil ditambahkan.');
        } catch (QueryException $e) {
            return redirect('margin-penjualan')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $this->validasi($request);

        try {
            // updated_at otomatis terisi karena $timestamps = true di model
            MarginPenjualan::findOrFail($id)->update($data);
            return redirect('margin-penjualan')->with('ok', 'Margin penjualan berhasil diubah.');
        } catch (QueryException $e) {
            return redirect('margin-penjualan')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            MarginPenjualan::findOrFail($id)->delete();
            return redirect('margin-penjualan')->with('ok', 'Margin penjualan berhasil dihapus.');
        } catch (QueryException $e) {
            return redirect('margin-penjualan')->with('err', $this->pesanGalat($e));
        }
    }

    private function validasi(Request $request): array
    {
        return $request->validate([
            'persen' => 'required|numeric|min:0',
            'status' => 'required|integer|between:0,9',
            'iduser' => 'required|integer',
        ]);
    }
}
