<?php

namespace App\Http\Controllers;
use Illuminate\Database\QueryException;

abstract class Controller
{
    // Pengganti Flash::error() di project lama
    protected function pesanGalat(QueryException $e): string
    {
        // 23000 = pelanggaran constraint (duplikat PK atau masih dipakai FK)
        if ($e->getCode() == '23000') {
            return 'Gagal: data duplikat atau masih dipakai tabel lain (terhubung lewat foreign key).';
        }

        // pesan asli dari MySQL (mis. dari trigger), tanpa potongan SQL-nya
        return 'Gagal: ' . ($e->errorInfo[2] ?? $e->getMessage());
    }
}
