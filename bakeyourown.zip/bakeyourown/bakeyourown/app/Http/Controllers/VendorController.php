<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Vendor;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class VendorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        return view('vendor.index', [
            'edit' => $request->query('edit') ? Vendor::find($request->query('edit')) : null,
            'rows' => DB::select('SELECT * FROM v_vendorjmlbarang ORDER BY `No.`'),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $this->validasi($request);

        try {
            $vendor = new Vendor($data);
            $vendor->idvendor = (Vendor::max('idvendor') ?? 0) + 1;
            $vendor->save();
            return redirect('vendor')->with('ok', 'Vendor berhasil ditambahkan.');
        } catch (QueryException $e) {
            return redirect('vendor')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $this->validasi($request);

        try {
            Vendor::findOrFail($id)->update($data);
            return redirect('vendor')->with('ok', 'Vendor berhasil diubah.');
        } catch (QueryException $e) {
            return redirect('vendor')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            Vendor::findOrFail($id)->delete();
            return redirect('vendor')->with('ok', 'Vendor berhasil dihapus.');
        } catch (QueryException $e) {
            return redirect('vendor')->with('err', $this->pesanGalat($e));
        }
    }

    private function validasi(Request $request): array
    {
        return $request->validate([
            'nama_vendor' => 'required|max:100',
            'badan_hukum' => 'required|size:1',
            'status'      => 'required|size:1',
        ]);
    }
}
