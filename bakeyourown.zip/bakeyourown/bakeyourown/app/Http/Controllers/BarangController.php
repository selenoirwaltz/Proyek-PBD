<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barang;
use App\Models\Satuan;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class BarangController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        return view('barang.index', [
            'edit'         => $request->query('edit') ? Barang::find($request->query('edit')) : null,
            'rows'         => DB::select('SELECT * FROM v_baranglengkap ORDER BY `No.`'),
            'rows2'        => DB::select('SELECT * FROM v_barangnonaktif ORDER BY `No.`'),
            'hargaMurah'   => DB::select('CALL sp_laporan_harga_dibawah(?)', [20000]),
            'daftarSatuan' => Satuan::orderBy('idsatuan')->get(),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $this->validasi($request);

        try {
            $barang = new Barang($data);
            $barang->idbarang = (Barang::max('idbarang') ?? 0) + 1;
            $barang->save();
            return redirect('barang')->with('ok', 'Barang berhasil ditambahkan.');
        } catch (QueryException $e) {
            return redirect('barang')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $this->validasi($request);

        try {
            Barang::findOrFail($id)->update($data);
            return redirect('barang')->with('ok', 'Barang berhasil diubah.');
        } catch (QueryException $e) {
            return redirect('barang')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            Barang::findOrFail($id)->delete();
            return redirect('barang')->with('ok', 'Barang berhasil dihapus.');
        } catch (QueryException $e) {
            return redirect('barang')->with('err', $this->pesanGalat($e));
        }
    }

    private function validasi(Request $request): array
    {
        return $request->validate([
            'jenis'    => 'required|size:1',
            'nama'     => 'required|max:45',
            'idsatuan' => 'required|integer',
            'status'   => 'required|integer|between:0,9',
            'harga'    => 'required|integer|min:0',
        ]);
    }
}
