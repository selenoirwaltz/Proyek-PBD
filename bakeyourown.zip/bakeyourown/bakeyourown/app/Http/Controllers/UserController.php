<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        return view('user.index', [
            'edit'       => $request->query('edit') ? User::find($request->query('edit')) : null,
            'rows'       => DB::select('SELECT * FROM v_user_lengkap ORDER BY `No.`'),
            'daftarRole' => Role::orderBy('idrole')->get(),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'username' => 'required|max:45',
            'password' => 'required|max:50',
            'idrole'   => 'required|integer',
        ]);
        $data['password'] = Hash::make($data['password']);

        try {
            $user = new User($data);
            $user->iduser = (User::max('iduser') ?? 0) + 1;
            $user->save();
            return redirect('user')->with('ok', 'User berhasil ditambahkan.');
        } catch (QueryException $e) {
            return redirect('user')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $request->validate([
            'username' => 'required|max:45',
            'password' => 'nullable|max:50',
            'idrole'   => 'required|integer',
        ]);

        // password kosong = password lama dibiarkan
        if (filled($data['password'] ?? null)) {
            $data['password'] = Hash::make($data['password']);
        } else {
            unset($data['password']);
        }

        try {
            User::findOrFail($id)->update($data);
            return redirect('user')->with('ok', 'User berhasil diubah.');
        } catch (QueryException $e) {
            return redirect('user')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            User::findOrFail($id)->delete();
            return redirect('user')->with('ok', 'User berhasil dihapus.');
        } catch (QueryException $e) {
            return redirect('user')->with('err', $this->pesanGalat($e));
        }
    }
}
