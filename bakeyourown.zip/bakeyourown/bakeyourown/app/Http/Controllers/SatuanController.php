<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Satuan;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;

class SatuanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        return view('satuan.index', [
            'edit' => $request->query('edit') ? Satuan::find($request->query('edit')) : null,
            'rows' => DB::select('SELECT * FROM v_satuanjmlbarang ORDER BY `No.`'),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $this->validasi($request);

        try {
            $satuan = new Satuan($data);
            $satuan->idsatuan = (Satuan::max('idsatuan') ?? 0) + 1;
            $satuan->save();
            return redirect('satuan')->with('ok', 'Satuan berhasil ditambahkan.');
        } catch (QueryException $e) {
            return redirect('satuan')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $this->validasi($request);

        try {
            Satuan::findOrFail($id)->update($data);
            return redirect('satuan')->with('ok', 'Satuan berhasil diubah.');
        } catch (QueryException $e) {
            return redirect('satuan')->with('err', $this->pesanGalat($e));
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            Satuan::findOrFail($id)->delete();
            return redirect('satuan')->with('ok', 'Satuan berhasil dihapus.');
        } catch (QueryException $e) {
            return redirect('satuan')->with('err', $this->pesanGalat($e));
        }
    }

    private function validasi(Request $request): array
    {
        return $request->validate([
            'nama_satuan' => 'required|max:45',
            'status'      => 'required|integer|between:0,9',
        ]);
    }
}
