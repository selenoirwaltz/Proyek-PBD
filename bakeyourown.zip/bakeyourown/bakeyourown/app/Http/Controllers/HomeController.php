<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barang;
use App\Models\MarginPenjualan;
use App\Models\Role;
use App\Models\Satuan;
use App\Models\User;
use App\Models\Vendor;

class HomeController extends Controller
{
    public function index(){
        $jumlah = [
            'satuan'           => \App\Models\Satuan::count(),
            'vendor'           => \App\Models\Vendor::count(),
            'role'             => \App\Models\Role::count(),
            'barang'           => \App\Models\Barang::count(),
            'user'             => \App\Models\User::count(),
            'margin_penjualan' => \App\Models\MarginPenjualan::count(),
        ];
        return view('home', compact('jumlah'));
    }

}
