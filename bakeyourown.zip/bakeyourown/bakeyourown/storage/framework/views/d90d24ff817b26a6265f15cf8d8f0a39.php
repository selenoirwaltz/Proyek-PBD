<?php $__env->startSection('judul', 'Satuan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <h2><?php echo e($edit ? 'Ubah satuan' : 'Tambah satuan'); ?></h2>
  <form method="post" action="<?php echo e($edit ? url('satuan/'.$edit->idsatuan) : url('satuan')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($edit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="grid">
      <div><label>Nama satuan</label>
        <input name="nama_satuan" maxlength="45" required value="<?php echo e(old('nama_satuan', $edit?->nama_satuan)); ?>"></div>
      <div><label>Status</label>
        <input type="number" name="status" min="0" max="9" required value="<?php echo e(old('status', $edit?->status ?? 1)); ?>"></div>
    </div>
    <div class="aksi">
      <button class="btn"><?php echo e($edit ? 'Simpan perubahan' : 'Tambah'); ?></button>
      <?php if($edit): ?><a class="btn batal" href="<?php echo e(url('satuan')); ?>">Batal</a><?php endif; ?>
    </div>
  </form>
</div>

<div class="tabel-wrap">
<table>
  <tr><th>No.</th><th>Satuan</th><th>Jumlah Barang</th><th>Status Barang</th><th>Aksi</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
    <td><?php echo e($r->{'No.'}); ?></td>
    <td><?php echo e($r->{'Satuan'}); ?></td>
    <td><?php echo e($r->{'Jumlah Barang'}); ?></td>
    <td>
      <?php if($r->{'Status Barang'} == 1): ?>
        <span class="badge aktif">Aktif</span>
      <?php else: ?>
        <span class="badge nonaktif">Tidak Aktif</span>
      <?php endif; ?>
    </td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit=<?php echo e($r->{'No.'}); ?>">Ubah</a>
      <form method="post" action="<?php echo e(url('satuan/'.$r->{'No.'})); ?>" onsubmit="return confirm('Hapus satuan ini?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="5" class="kosong">Belum ada data.</td></tr>
  <?php endif; ?>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\bakeyourown\resources\views/satuan/index.blade.php ENDPATH**/ ?>