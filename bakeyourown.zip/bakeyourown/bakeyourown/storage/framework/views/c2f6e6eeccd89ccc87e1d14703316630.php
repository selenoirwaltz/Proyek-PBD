<?php $__env->startSection('judul', 'Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <h2><?php echo e($edit ? 'Ubah barang' : 'Tambah barang'); ?></h2>
  <form method="post" action="<?php echo e($edit ? url('barang/'.$edit->idbarang) : url('barang')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($edit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="grid">
      <div><label>Nama barang</label>
        <input name="nama" maxlength="45" required value="<?php echo e(old('nama', $edit?->nama)); ?>"></div>
      <div><label>Jenis (1 huruf, mis. a / b / c)</label>
        <input name="jenis" maxlength="1" required value="<?php echo e(old('jenis', $edit?->jenis)); ?>"></div>
      <div><label>Satuan</label>
        <select name="idsatuan" required>
          <option value="">-- pilih satuan --</option>
          <?php $__currentLoopData = $daftarSatuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s->idsatuan); ?>" <?php echo e(old('idsatuan', $edit?->idsatuan) == $s->idsatuan ? 'selected' : ''); ?>><?php echo e($s->nama_satuan); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></div>
      <div><label>Harga (Rp)</label>
        <input type="number" name="harga" min="0" required value="<?php echo e(old('harga', $edit?->harga)); ?>"></div>
      <div><label>Status</label>
        <input type="number" name="status" min="0" max="9" required value="<?php echo e(old('status', $edit?->status ?? 1)); ?>"></div>
    </div>
    <div class="aksi">
      <button class="btn"><?php echo e($edit ? 'Simpan perubahan' : 'Tambah'); ?></button>
      <?php if($edit): ?><a class="btn batal" href="<?php echo e(url('barang')); ?>">Batal</a><?php endif; ?>
    </div>
  </form>
</div>

<div class="tabel-wrap">
<h3>Barang Aktif</h3>
<table>
  <tr><th>No.</th><th>Jenis Barang</th><th>Nama Barang</th><th>Harga Barang</th><th>Satuan</th><th>Status Barang</th><th>Aksi</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
    <td><?php echo e($r->{'No.'}); ?></td>
    <td><?php echo e($r->{'Jenis Barang'}); ?></td>
    <td><?php echo e($r->{'Nama Barang'}); ?></td>
    <td>Rp <?php echo e(number_format($r->{'Harga Barang'}, 0, ',', '.')); ?></td>
    <td><?php echo e($r->{'Satuan'}); ?></td>
    <td>
      <?php if($r->{'Status Barang'} == 1): ?>
        <span class="badge aktif">Aktif</span>
      <?php else: ?>
        <span class="badge nonaktif">Tidak Aktif</span>
      <?php endif; ?>
    </td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit=<?php echo e($r->{'No.'}); ?>">Ubah</a>
      <form method="post" action="<?php echo e(url('barang/'.$r->{'No.'})); ?>" onsubmit="return confirm('Hapus barang ini?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="7" class="kosong">Belum ada data.</td></tr>
  <?php endif; ?>
</table>
</div>

<div class="tabel-wrap" style="margin-top: 30px;">
<h3>Barang Nonaktif</h3>
<table>
  <tr><th>No.</th><th>Jenis Barang</th><th>Nama Barang</th><th>Harga Barang</th><th>Satuan</th><th>Status Barang</th><th>Aksi</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $rows2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
    <td><?php echo e($r->{'No.'}); ?></td>
    <td><?php echo e($r->{'Jenis Barang'}); ?></td>
    <td><?php echo e($r->{'Nama Barang'}); ?></td>
    <td>Rp <?php echo e(number_format($r->{'Harga Barang'}, 0, ',', '.')); ?></td>
    <td><?php echo e($r->{'Satuan'}); ?></td>
    <td><span class="badge nonaktif">Tidak Aktif</span></td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit=<?php echo e($r->{'No.'}); ?>">Ubah</a>
      <form method="post" action="<?php echo e(url('barang/'.$r->{'No.'})); ?>" onsubmit="return confirm('Hapus barang ini?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="7" class="kosong">Tidak ada data barang yang tidak aktif.</td></tr>
  <?php endif; ?>
</table>
</div>

<div class="tabel-wrap" style="margin-top: 30px;">
<h3>Harga di Bawah Rp20.000</h3>
<table>
  <tr><th>No.</th><th>Jenis</th><th>Nama Barang</th><th>Harga</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $hargaMurah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
    <td><?php echo e($sm->idbarang); ?></td>
    <td><?php echo e($sm->jenis); ?></td>
    <td><?php echo e($sm->nama); ?></td>
    <td>Rp <?php echo e(number_format($sm->harga, 0, ',', '.')); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="4" class="kosong">Tidak ada harga di bawah Rp20.000</td></tr>
  <?php endif; ?>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\bakeyourown\resources\views/barang/index.blade.php ENDPATH**/ ?>