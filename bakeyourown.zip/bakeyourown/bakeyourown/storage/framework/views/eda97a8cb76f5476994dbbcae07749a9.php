<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('judul'); ?> - BakeYourOwn Inventory</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

  
  <button id="sidebar-toggle" class="hamburger-btn">&#9776;</button>

  
  <?php
    $menu = ['/' => 'Beranda', 'barang' => 'Barang', 'satuan' => 'Satuan', 'vendor' => 'Vendor',
             'margin-penjualan' => 'Margin Penjualan', 'user' => 'User', 'role' => 'Role'];
  ?>
  <aside id="sidebar" class="sidebar">
    <div class="sidebar-header"><h3>BakeYourOwn Inventory</h3></div>
    <ul class="sidebar-menu">
      <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(url($url)); ?>" class="<?php echo e(request()->is($url === '/' ? '/' : $url.'*') ? 'active' : ''); ?>"><?php echo e($nama); ?></a></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </aside>

  
  <div id="main-content" class="main-content">
    <div class="container">
      
      <?php echo $__env->yieldContent('content'); ?>
    </div>
  </div>

  
  <script>
      const toggleBtn = document.getElementById('sidebar-toggle');
      const sidebar = document.getElementById('sidebar');
      const mainContent = document.getElementById('main-content');

      toggleBtn.addEventListener('click', function() {
          sidebar.classList.toggle('closed');
          mainContent.classList.toggle('expanded');
      });
  </script>
</body>
</html>
<?php /**PATH C:\Users\user\bakeyourown\resources\views/layouts/app.blade.php ENDPATH**/ ?>