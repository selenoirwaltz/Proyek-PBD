<?php $__env->startSection('judul', 'Margin Penjualan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <h2><?php echo e($edit ? 'Ubah margin' : 'Tambah margin'); ?></h2>
  <form method="post" action="<?php echo e($edit ? url('margin-penjualan/'.$edit->idmargin_penjualan) : url('margin-penjualan')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($edit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="grid">
      <div><label>Persen (%)</label>
        <input type="number" name="persen" step="0.01" min="0" required value="<?php echo e(old('persen', $edit?->persen)); ?>"></div>
      <div><label>Status</label>
        <input type="number" name="status" min="0" max="9" required value="<?php echo e(old('status', $edit?->status ?? 1)); ?>"></div>
      <div><label>Dibuat oleh (user)</label>
        <select name="iduser" required>
          <option value="">-- pilih user --</option>
          <?php $__currentLoopData = $daftarUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->iduser); ?>" <?php echo e(old('iduser', $edit?->iduser) == $u->iduser ? 'selected' : ''); ?>><?php echo e($u->username); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></div>
    </div>
    <div class="aksi">
      <button class="btn"><?php echo e($edit ? 'Simpan perubahan' : 'Tambah'); ?></button>
      <?php if($edit): ?><a class="btn batal" href="<?php echo e(url('margin-penjualan')); ?>">Batal</a><?php endif; ?>
    </div>
  </form>
</div>

<div class="tabel-wrap">
<table>
  <tr><th>No.</th><th>Persentase</th><th>Status Margin</th><th>Nama User</th><th>Tanggal Dibuat</th><th>Tanggal Diubah</th><th>Aksi</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
    <td><?php echo e($r->{'No.'}); ?></td>
    <td><?php echo e($r->{'Persentase'}); ?>%</td>
    <td><?php echo e($r->{'Status Margin'}); ?></td>
    <td><?php echo e($r->{'Nama User'}); ?></td>
    <td><?php echo e($r->{'Tanggal Dibuat'}); ?></td>
    <td><?php echo e($r->{'Tanggal Diubah'} ?? '-'); ?></td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit=<?php echo e($r->{'No.'}); ?>">Ubah</a>
      <form method="post" action="<?php echo e(url('margin-penjualan/'.$r->{'No.'})); ?>" onsubmit="return confirm('Hapus margin ini?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="7" class="kosong">Belum ada data.</td></tr>
  <?php endif; ?>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\bakeyourown\resources\views/margin/index.blade.php ENDPATH**/ ?>