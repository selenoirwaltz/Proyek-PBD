<?php $__env->startSection('judul', 'User'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <h2><?php echo e($edit ? 'Ubah user' : 'Tambah user'); ?></h2>
  <form method="post" action="<?php echo e($edit ? url('user/'.$edit->iduser) : url('user')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($edit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="grid">
      <div><label>Username</label>
        <input name="username" maxlength="45" required value="<?php echo e(old('username', $edit?->username)); ?>"></div>
      <div><label>Password <?php echo e($edit ? '(kosongkan jika tidak diganti)' : ''); ?></label>
        <input type="password" name="password" maxlength="50" <?php echo e($edit ? '' : 'required'); ?>></div>
      <div><label>Role</label>
        <select name="idrole" required>
          <option value="">-- pilih role --</option>
          <?php $__currentLoopData = $daftarRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($rl->idrole); ?>" <?php echo e(old('idrole', $edit?->idrole) == $rl->idrole ? 'selected' : ''); ?>><?php echo e($rl->nama_role); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select></div>
    </div>
    <div class="aksi">
      <button class="btn"><?php echo e($edit ? 'Simpan perubahan' : 'Tambah'); ?></button>
      <?php if($edit): ?><a class="btn batal" href="<?php echo e(url('user')); ?>">Batal</a><?php endif; ?>
    </div>
  </form>
</div>

<div class="tabel-wrap">
<table>
  <tr><th>No.</th><th>Nama User</th><th>Role</th><th>Aksi</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
    <td><?php echo e($r->{'No.'}); ?></td>
    <td><?php echo e($r->{'Nama User'}); ?></td>
    <td><?php echo e($r->{'Role'}); ?></td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit=<?php echo e($r->{'No.'}); ?>">Ubah</a>
      <form method="post" action="<?php echo e(url('user/'.$r->{'No.'})); ?>" onsubmit="return confirm('Hapus user ini?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="4" class="kosong">Belum ada data.</td></tr>
  <?php endif; ?>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\bakeyourown\resources\views/user/index.blade.php ENDPATH**/ ?>