<?php $__env->startSection('judul', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
<p>Kelola data master. Pilih tabel di bawah untuk tambah, ubah, atau hapus data.</p>
<div class="menu-grid">
  <a href="<?php echo e(url('satuan')); ?>">Satuan <small><?php echo e($jumlah['satuan']); ?> data</small></a>
  <a href="<?php echo e(url('vendor')); ?>">Vendor <small><?php echo e($jumlah['vendor']); ?> data</small></a>
  <a href="<?php echo e(url('role')); ?>">Role <small><?php echo e($jumlah['role']); ?> data</small></a>
  <a href="<?php echo e(url('barang')); ?>">Barang <small><?php echo e($jumlah['barang']); ?> data</small></a>
  <a href="<?php echo e(url('user')); ?>">User <small><?php echo e($jumlah['user']); ?> data</small></a>
  <a href="<?php echo e(url('margin-penjualan')); ?>">Margin Penjualan <small><?php echo e($jumlah['margin_penjualan']); ?> data</small></a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\bakeyourown\resources\views/home.blade.php ENDPATH**/ ?>