<?php $__env->startSection('judul', 'Role'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <h2><?php echo e($edit ? 'Ubah role' : 'Tambah role'); ?></h2>
  <form method="post" action="<?php echo e($edit ? url('role/'.$edit->idrole) : url('role')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($edit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="grid">
      <div><label>Nama role</label>
        <input name="nama_role" maxlength="100" required value="<?php echo e(old('nama_role', $edit?->nama_role)); ?>"></div>
    </div>
    <div class="aksi">
      <button class="btn"><?php echo e($edit ? 'Simpan perubahan' : 'Tambah'); ?></button>
      <?php if($edit): ?><a class="btn batal" href="<?php echo e(url('role')); ?>">Batal</a><?php endif; ?>
    </div>
  </form>
</div>

<div class="tabel-wrap">
<table>
  <tr><th>No.</th><th>Role</th><th>Total User</th><th>Aksi</th></tr>
  <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <tr>
    <td><?php echo e($r->{'No.'}); ?></td>
    <td><?php echo e($r->{'Role'}); ?></td>
    <td><?php echo e($r->{'Total User'}); ?></td>
    <td class="aksi-sel">
      <a class="btn kecil edit" href="?edit=<?php echo e($r->{'No.'}); ?>">Ubah</a>
      <form method="post" action="<?php echo e(url('role/'.$r->{'No.'})); ?>" onsubmit="return confirm('Hapus role ini?')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn kecil hapus">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <tr><td colspan="4" class="kosong">Belum ada data.</td></tr>
  <?php endif; ?>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\bakeyourown\resources\views/role/index.blade.php ENDPATH**/ ?>